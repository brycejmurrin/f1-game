---
name: f1-agent-coordination
description: "Use when setting up brycejmurrin/f1-game to work with agents, delegating project work, coordinating subagents, inspecting external session access, or sending and reading the Apex fleet bus. Distinguish native agents from independent Codex Cloud, Claude Code and Cursor sessions."
---

# F1 agent coordination

Start with the actual task. An agent/setup request is about the development environment; do not start fixing gameplay bugs. Use the parent host's native collaboration controls when the user asks for agent work. Do not require a game browser, local Codex CLI, provider API key or new MCP server to use already-exposed native agents.

## Choose and verify the route

1. Inspect the tools exposed in this session. Repository `.mcp.json`, installed skills and plugin manifests describe configuration, not active connections. A tool-name snapshot contains names only, never descriptions or credentials.
2. Run `node <plugin-root>/scripts/agent-readiness.mjs --catalog <fresh-host-tools.json>` when local execution is available. Record native collaboration names separately when they are advertised outside the connector registry. No snapshot means UNKNOWN, not unavailable. This report detects names; its `AVAILABLE_NEEDS_LIVE_TEST` is not a verified service result.
3. Native team: use exposed spawn, message, follow-up, status, wait and interrupt controls. On the current hosted Codex surface these are `collaboration.spawn_agent`, `send_message`, `followup_task`, `list_agents`, `wait_agent`, and `interrupt_agent`. Use these as direct host calls, outside code-mode orchestration. Inspect the live schema before calling; other hosts use different names. For setup verification, create one read-only worker, receive a READY message, send a nonce follow-up and verify the exact reply. Report the observed worker limit rather than promising a fixed global limit.
4. Cross-session coordination: use the existing `claude/fleet-bus` branch in `brycejmurrin/f1-game`. Prefer the repository's fleet CLI when shell Git authentication works. If shell credentials are absent but the GitHub connector is connected, use the connector adapter in [the transport reference](references/transports.md). Native child IDs, vendor session IDs and claims-board hashes are different identifiers.
5. Independent external launches: discover a provider-specific authenticated service before attempting launch or follow-up. The fleet bus does not create or wake agents. Native children do not become independent Codex Cloud tasks. General ChatGPT chats are not addressable agent sessions. Report a missing connection explicitly, and never pretend that changing a manifest or installing a skill supplies it.

## Delegate safely and finish the work

Read the checkout's current `AGENTS.md`, fleet rules and applicable subsystem skill before project edits. Check path ownership and active PRs using the connector when shell authentication fails. Give each worker a bounded objective, owned paths, forbidden paths, relevant context, expected evidence and a hand-back format. Do not let two workers edit the same file. These workers share the host filesystem unless an actual separate worktree was created.

Workers inherit host permissions and available tools; a prompt does not grant extra sandbox access. Each worker's model/tool work consumes usage. Do not bypass a denial, change permissions or invent API access. Keep browser ownership and serialized browser runs with the parent when the checkout requires it.

Steer running workers with messages. Reuse an idle worker with a follow-up. Collect and review their evidence, integrate independent changes, then run the checkout's verification and PR flow. A returned result is not proof that the implementation is correct. Work done in a sibling vendor session remains in that session's branch/workspace until integrated.

Keep durable status in the existing PR body and fleet bus. A message recorded on GitHub is not acknowledged until the recipient replies or updates its status. Read the bus once per check-in; do not spin or invent push subscriptions. Report gaps in a bounded history window rather than claiming an exhaustive session inventory.

For private plugin updates preserve its identity, audience and local MCP connections. A saved release and active host tool exposure are separate outcomes. A hosted chat may use skills and checkout CLIs without exposing the plugin's local stdio servers; refreshing the chat does not guarantee stdio support. Use an authenticated remote MCP or supported executor only when direct host attachment is actually needed.

## Completion

Report separately: native spawn/messaging evidence; fleet read/write receipt; provider session access; unverified launches; and the saved plugin version. Do not describe a bus receipt as external-agent launch or delivery acknowledgement. Do not claim every capability is enabled when a provider still needs a supported connection.

