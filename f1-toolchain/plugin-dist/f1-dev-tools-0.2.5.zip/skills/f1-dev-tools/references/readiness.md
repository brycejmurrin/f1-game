# Cold-start readiness and handoff

Run the plugin-root `scripts/readiness.mjs` from the intended checkout:

```sh
node /path/to/plugin/scripts/readiness.mjs --checkout "$PWD" --out artifacts/f1-readiness.json
```

The checkout path is mandatory and exact: no automatic choice among worktrees. The script checks the existing Apex wrapper, Git identity and working tree, then calls `apex_status`, `apex_catalog` and `apex_doctor` serially with a per-call timeout. It does not run the bootstrap, install dependencies, acquire a browser, change settings, or attach a server. Run the checkout's documented bootstrap separately if needed. An unsupported/missing wrapper or unreadable result is FAIL, never an empty successful result.

For host discovery, save the active session's actual tool names as a JSON array of strings, or an object with a `tools` array of strings / objects with `name`. Then add `--catalog /absolute/path/to/host-tools.json`. Do not use `.mcp.json` or a package manifest as a host snapshot. No snapshot = UNKNOWN; an empty snapshot = no relevant tool exposed. A matched name establishes exposure only. The snapshot is user-supplied evidence; this CLI cannot authenticate its freshness or make host tool calls.

The report separates three declared MCP servers from exposed tools and executed local CLI checks. It does not repeat the checkout catalog; counts and warnings point back to current discovery. `overall: PARTIAL` is expected while host service checks and rendered behavior are SKIP. Exit 0 means local checks passed, even when overall coverage is PARTIAL; exit 1 means a local check failed. Do not label the entire host verified because a local exit is zero.

When attachment is absent, use the checkout CLI fallbacks while preserving their scope: LSP via `bash tools/mcp/lsp-mcp.sh`, persistent debugger via its documented wrapper, and browser setup/cleanup via `.claude/skills/mcp-probe/references/offline.md`. Missing tmux or an unwritable browser cache is reported by doctor; it is not repaired by changing permissions. After an account update, inspect actual host exposure again. A supporting local executor can reload stdio connections; a new hosted chat does not guarantee attachment. Make a harmless attached call only when the tools are exposed.

Handoff includes: report location, checked Git SHA, local checks and warnings, supplied host-snapshot state, missing exposed tools, and unexecuted host/browser checks. A report under ignored artifacts is local evidence; transfer it or explicitly state that it is local-only. Do not include career saves, tokens, process environments, or full tool descriptions.



