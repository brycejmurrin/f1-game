# Prepared F1 cloud environment

The current managed checkout is `/workspace/f1-game`; verify its identity and
read its AGENTS.md before editing it. The retained environment toolchain is
`/workspace/f1-toolchain`. Read its ENVIRONMENT.md before local recovery.

Discover actual exposed tools and call hosted apex_status first. If it returns
`Session terminated`, distinguish a stale hosted session from missing tools or
authorization. With this attached executor, run the read-only
`/workspace/f1-toolchain/bin/f1-env doctor`, then the idempotent
`/workspace/f1-toolchain/bin/f1-env resume` for local gateway recovery. Startup
reuses the lifecycle manager; do not launch duplicate tunnels or MCP servers.
Do not install dependencies as part of startup. A failed doctor requires the
documented installation or restoration process, not credential replacement.

Recheck the hosted status after local recovery. Local readiness does not prove
that the host session has reconnected. If it still fails, use documented checkout
CLI fallbacks and report hosted calls as unavailable. Do not recreate the app,
tunnel identity or connection to work around a stale session.

The cloud runtime status reports current readiness of PLAYWRIGHT_BROWSERS_PATH,
APEX_CHAT_MCP_PROFILE, APEX_TUNNEL_CLIENT_BIN and CONTROL_PLANE_API_KEY. Never
print their values, profiles, secret files or process environments. Existing
runtime bindings are the source of truth; use them rather than hardcoded values.
Browser localhost refers to the browser's own executor. Respect repository
occupancy and locks; use one browser workflow at a time.

Package builds: `/workspace/f1-toolchain/bin/f1-build-plugins` and its `--check`
mode validate retained sources and archives without publishing. Account release
updates, local gateway readiness, hosted calls and rendered behavior must be
verified and reported separately. Do not require a local executor for working
hosted read-only tools. Do not request sandbox escalation in an environment whose
approval policy disables it; report the actual missing capability instead.

## Branch-independent runtime (0.2.5)

The lifecycle manager, gateway, contract checker and separately locked SDK live
under `/workspace/f1-toolchain/runtime/`. Startup uses the tunnel client's supported
`--mcp.command` override, retaining the profile and credential references unchanged.
It does not depend on unmerged lifecycle files in the game checkout. Missing
runtime sources fail `f1-env doctor`; restore the retained sources before installing.
Use `f1-env install` only for dependencies or tooling that actually need repair.
The npm Chrome DevTools pin is supported; the optional source clone is skipped
by default through activation. No `/opt/google/chrome/chrome` alias is required
when the repository wrapper supplies the discovered executable.

A healthy local catalog, readyz 200 and control-plane poll are local transport
checks. Still discover and call hosted tools before claiming chat attachment.
